
function toggleDarkMode() {
  document.body.classList.toggle("dark");
  document.querySelector(".toggle-theme").textContent =
    document.body.classList.contains("dark") ? "☀" : "🌙";
}

function showRegister() {
  document.getElementById("loginPage").classList.add("hidden");
  document.getElementById("registerPage").classList.remove("hidden");
}

function showLogin() {
  document.getElementById("registerPage").classList.add("hidden");
  document.getElementById("loginPage").classList.remove("hidden");
  document.getElementById("errorMessage").classList.add("hidden");
}

function handleRegister(event) {
  event.preventDefault();
  const inputs = event.target.querySelectorAll("input");
  const name = inputs[0].value.trim();
  const email = inputs[1].value.trim();
  const password = inputs[2].value;
  const confirmPassword = inputs[3].value;

  if (password !== confirmPassword) {
    alert("كلمة المرور غير متطابقة");
    return;
  }

  localStorage.setItem("userEmail", email);
  localStorage.setItem("userPassword", password);
  localStorage.setItem("userName", name);

  alert("تم إنشاء الحساب بنجاح");
  showLogin();
}

function login(event) {
  event.preventDefault();
  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPassword").value;

  const storedEmail = localStorage.getItem("userEmail");
  const storedPassword = localStorage.getItem("userPassword");

  if (email === storedEmail && password === storedPassword) {
    startApp();
  } else {
    document.getElementById("errorMessage").classList.remove("hidden");
  }
}

function startApp() {
  document.getElementById("loginPage").style.display = "none";
  document.getElementById("registerPage").style.display = "none";
  document.getElementById("mainApp").style.display = "flex";
}

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(pageId).classList.add('active');
}

function hidePages() {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
}
